angular
    .module('altairApp')
    .controller('numericTextboxCtrl', [
        '$scope',
        function ($scope) {
            $scope.value = 50;
        }
    ]);